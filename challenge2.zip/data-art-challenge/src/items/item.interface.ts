export interface BaseItem {
  name: string;
  price: number;
  description: string;
  image: string;
}

export interface RealItem extends BaseItem {
  id: number;
};
